# Changelog for lambda-calculus

## Unreleased changes
