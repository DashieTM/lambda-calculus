import Test.Hspec
import Test.QuickCheck

main :: IO ()
main = hspec $ do
  describe "Prelude.head" $ do
    it "test 1" $ do
      (reduce (App (Abs "x" (Var "x")) (Var "a"))) `shouldBe` (Var "a")



--test1 = TestCase (assertEqual "for term1"  )
--tests = TestList [TestLabel "test1" test1]

